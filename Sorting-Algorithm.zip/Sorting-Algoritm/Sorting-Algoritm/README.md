# Sorting-Algoritm

Different types of sorting techniques like selection, Insertion, Merge, Quick and Bubble sort
